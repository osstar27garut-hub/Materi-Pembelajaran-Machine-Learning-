
const SPREADSHEET_ID = ''; // Kosongkan jika script dibuat dari Google Spreadsheet (bound script).
const SHEET_NAME = 'Hasil Quiz';

const QUESTIONS = [
  // 10 PILIHAN GANDA
  {id:'PG1', type:'pg', level:'Biasa', q:'Apa kepanjangan dari AI?', options:['Artificial Intelligence','Automatic Internet','Advanced Information','Artificial Internet'], answer:'A'},
  {id:'PG2', type:'pg', level:'Biasa', q:'Contoh AI yang sering digunakan untuk memberikan rekomendasi video adalah...', options:['Kalkulator biasa','Sistem rekomendasi','Kabel USB','Keyboard'], answer:'B'},
  {id:'PG3', type:'pg', level:'Medium', q:'Dalam konsep sederhana kerja AI, data digunakan terutama untuk...', options:['Dihapus setelah dipakai','Menjadi bahan bagi sistem untuk menemukan pola','Menggantikan listrik','Memperbesar ukuran file'], answer:'B'},
  {id:'PG4', type:'pg', level:'Medium', q:'Machine Learning merupakan pendekatan AI yang memungkinkan komputer...', options:['Belajar menemukan pola dari data','Selalu bekerja tanpa data','Hanya menghitung angka','Tidak pernah berubah hasilnya'], answer:'A'},
  {id:'PG5', type:'pg', level:'Medium', q:'Deep Learning banyak menggunakan...', options:['Jaringan saraf dengan banyak lapisan','Kertas dan pensil','Database tanpa algoritma','Kabel jaringan saja'], answer:'A'},
  {id:'PG6', type:'pg', level:'Hot', q:'Sebuah sekolah menggunakan AI untuk memprediksi siswa yang berisiko terlambat berdasarkan data kehadiran. Hal terpenting sebelum memakai hasil prediksi adalah...', options:['Langsung menghukum siswa','Memeriksa kualitas data dan menggunakan hasil sebagai bahan pertimbangan','Menghapus semua data','Membuat prediksi tanpa pengujian'], answer:'B'},
  {id:'PG7', type:'pg', level:'Hot', q:'AI memberikan jawaban yang terdengar meyakinkan tetapi ternyata salah. Kondisi ini menunjukkan bahwa pengguna harus...', options:['Percaya semua jawaban AI','Melakukan verifikasi terhadap informasi penting','Menganggap AI selalu benar','Menghapus internet'], answer:'B'},
  {id:'PG8', type:'pg', level:'Hot', q:'Jika data pelatihan AI lebih banyak berasal dari satu kelompok dan kurang mewakili kelompok lain, risiko yang dapat muncul adalah...', options:['Bias','Internet lebih cepat','File otomatis kecil','Baterai bertambah'], answer:'A'},
  {id:'PG9', type:'pg', level:'Hot', q:'Mana penggunaan AI yang paling bertanggung jawab untuk tugas sekolah?', options:['Menyalin seluruh jawaban tanpa memahami','Menggunakan AI untuk ide lalu memeriksa dan mengembangkan dengan pemahaman sendiri','Mengaku semua hasil AI sebagai karya pribadi','Memasukkan data pribadi teman tanpa izin'], answer:'B'},
  {id:'PG10', type:'pg', level:'Hot', q:'Mengapa privasi penting ketika menggunakan AI?', options:['Karena semua data pasti tidak berguna','Karena data yang dimasukkan dapat mengandung informasi pribadi yang perlu dilindungi','Karena AI tidak membutuhkan data','Karena privasi hanya berlaku di sekolah'], answer:'B'},

  // 5 MENJODOHKAN
  {id:'J1', type:'matching', level:'Biasa', q:'Cocokkan istilah berikut dengan pengertiannya.', pairs:[
    ['Artificial Intelligence','Bidang yang membuat komputer mampu melakukan tugas yang membutuhkan kecerdasan manusia'],
    ['Machine Learning','Metode AI yang belajar dari data untuk menemukan pola'],
    ['Deep Learning','Pendekatan machine learning dengan jaringan saraf berlapis-lapis'],
    ['Generative AI','AI yang dapat menghasilkan konten baru berdasarkan masukan'],
    ['Dataset','Kumpulan data yang digunakan untuk analisis atau pelatihan']
  ]},

  // 5 JAWABAN LEBIH DARI SATU
  {id:'MA1', type:'multi', level:'Biasa', q:'Pilih semua contoh penggunaan AI yang mungkin kamu temui sehari-hari.', options:['Rekomendasi film','Pengenalan wajah','Koreksi/Prediksi teks','Meja belajar biasa','Asisten suara'], answer:['A','B','C','E']},
  {id:'MA2', type:'multi', level:'Medium', q:'Pilih semua manfaat AI yang tepat.', options:['Membantu menganalisis data','Membantu otomatisasi pekerjaan tertentu','Selalu menjamin jawaban 100% benar','Membantu personalisasi layanan','Dapat membantu proses belajar'], answer:['A','B','D','E']},
  {id:'MA3', type:'multi', level:'Medium', q:'Pilih semua hal yang perlu diperhatikan ketika menggunakan AI.', options:['Akurasi informasi','Privasi data','Bias','Sumber informasi','Menyalin semua jawaban tanpa mengecek'], answer:['A','B','C','D']},
  {id:'MA4', type:'multi', level:'Hot', q:'Sebuah kelompok memakai AI untuk membuat presentasi. Pilih tindakan yang bertanggung jawab.', options:['Memeriksa fakta','Menyebutkan penggunaan AI jika diperlukan','Memasukkan data pribadi teman sembarangan','Mengubah dan memahami materi dengan kemampuan sendiri','Memeriksa apakah gambar/teks boleh digunakan'], answer:['A','B','D','E']},
  {id:'MA5', type:'multi', level:'Hot', q:'Pilih pernyataan yang benar tentang hubungan AI, Machine Learning, dan Deep Learning.', options:['Machine Learning adalah salah satu pendekatan dalam AI','Deep Learning merupakan bagian dari Machine Learning','Semua AI pasti Deep Learning','Deep Learning menggunakan jaringan saraf dengan banyak lapisan','AI hanya bisa bekerja tanpa data'], answer:['A','B','D']},

  // 5 ESAI
  {id:'E1', type:'essay', level:'Biasa', q:'Jelaskan dengan bahasamu sendiri apa yang dimaksud dengan Artificial Intelligence (AI).', keywords:['kecerdasan','buatan','komputer','mesin']},
  {id:'E2', type:'essay', level:'Medium', q:'Jelaskan secara sederhana bagaimana AI dapat belajar dari data.', keywords:['data','pola','belajar','hasil']},
  {id:'E3', type:'essay', level:'Medium', q:'Sebutkan dan jelaskan dua contoh AI yang kamu temui dalam kehidupan sehari-hari.', keywords:['contoh','rekomendasi','wajah','suara','chatbot','kamera','peta']},
  {id:'E4', type:'essay', level:'Hot', q:'Menurutmu, apa risiko jika seseorang terlalu percaya pada jawaban AI tanpa melakukan verifikasi? Jelaskan.', keywords:['salah','informasi','verifikasi','hoaks','bias','keputusan']},
  {id:'E5', type:'essay', level:'Hot', q:'Bayangkan sekolahmu ingin memakai AI untuk membantu kegiatan belajar. Usulkan satu penggunaan AI yang bermanfaat dan jelaskan cara agar penggunaannya tetap bertanggung jawab.', keywords:['belajar','sekolah','privasi','guru','verifikasi','data','bertanggung jawab']}
];

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('Quiz Tugas 1 — Artificial Intelligence')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function getQuestions() {
  return QUESTIONS.map(q => {
    const x = JSON.parse(JSON.stringify(q));
    delete x.answer;
    delete x.keywords;
    return x;
  });
}

function getSheet_() {
  const ss = SPREADSHEET_ID
    ? SpreadsheetApp.openById(SPREADSHEET_ID)
    : SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) sh = ss.insertSheet(SHEET_NAME);
  const headers = ['Timestamp','Nama','Kelas','PG','Menjodohkan','Multi','Esai','Nilai','Status','Ranking','Durasi'];
  if (sh.getLastRow() === 0) sh.appendRow(headers);
  else if (sh.getRange(1,1,1,headers.length).getValues()[0].join('|') !== headers.join('|')) {
    sh.clear();
    sh.appendRow(headers);
  }
  return sh;
}

function normalize_(s) {
  return String(s || '').toLowerCase().trim();
}

function gradeEssay_(answer, keywords) {
  const text = normalize_(answer);
  if (!text) return 0;
  const hits = keywords.filter(k => text.includes(normalize_(k))).length;
  if (hits >= Math.ceil(keywords.length * 0.75)) return 100;
  if (hits >= Math.ceil(keywords.length * 0.5)) return 75;
  if (hits >= 1) return 50;
  return 25;
}

function sameArray_(a,b) {
  a = (a || []).map(String).sort();
  b = (b || []).map(String).sort();
  return a.length === b.length && a.every((v,i)=>v===b[i]);
}

function calculate_(answers) {
  let pgCorrect=0, matchCorrect=0, multiCorrect=0, essayTotal=0;
  QUESTIONS.forEach(q => {
    const a = answers[q.id];
    if (q.type === 'pg') {
      if (a === q.answer) pgCorrect++;
    } else if (q.type === 'matching') {
      const obj = a || {};
      let c=0;
      q.pairs.forEach((p,i)=>{
        if (normalize_(obj[String(i)]) === normalize_(p[1])) c++;
      });
      matchCorrect += c;
    } else if (q.type === 'multi') {
      if (sameArray_(a,q.answer)) multiCorrect++;
    } else if (q.type === 'essay') {
      essayTotal += gradeEssay_(a,q.keywords);
    }
  });

  const pgScore = pgCorrect / 10 * 25;
  const matchScore = matchCorrect / 5 * 20;
  const multiScore = multiCorrect / 5 * 25;
  const essayScore = essayTotal / 5 * 30;
  const total = Math.round((pgScore + matchScore + multiScore + essayScore) * 100) / 100;
  return {
    pg: Math.round(pgScore*100)/100,
    matching: Math.round(matchScore*100)/100,
    multi: Math.round(multiScore*100)/100,
    essay: Math.round(essayScore*100)/100,
    total
  };
}

function submitQuiz(data) {
  if (!data || !data.nama || !data.kelas) throw new Error('Nama dan kelas wajib diisi.');
  const answers = data.answers || {};
  const score = calculate_(answers);
  const sh = getSheet_();
  sh.appendRow([
    new Date(), data.nama, data.kelas,
    score.pg, score.matching, score.multi, score.essay,
    score.total, score.total >= 75 ? 'LULUS' : 'PERLU BELAJAR LAGI',
    '', data.duration || ''
  ]);
  SpreadsheetApp.flush();
  updateRanking_();
  const rows = sh.getDataRange().getValues();
  const last = rows[rows.length-1];
  return {score, rank:last[9], message:'Jawaban berhasil disimpan ke Spreadsheet.'};
}

function updateRanking_() {
  const sh = getSheet_();
  const lastRow = sh.getLastRow();
  if (lastRow < 2) return;
  const data = sh.getRange(2,1,lastRow-1,11).getValues();
  const sorted = data.map((r,i)=>({row:i+2, score:Number(r[7])||0, time:r[0]}))
    .sort((a,b)=>b.score-a.score || new Date(a.time)-new Date(b.time));
  const rankByRow = {};
  sorted.forEach((x,i)=>rankByRow[x.row]=i+1);
  Object.keys(rankByRow).forEach(r=>sh.getRange(Number(r),10).setValue(rankByRow[r]));
}

function getRanking() {
  const sh = getSheet_();
  updateRanking_();
  const values = sh.getDataRange().getValues();
  if (values.length <= 1) return [];
  return values.slice(1).map(r=>({
    nama:r[1], kelas:r[2], nilai:r[7], status:r[8], ranking:r[9]
  })).sort((a,b)=>Number(a.ranking)-Number(b.ranking));
}
