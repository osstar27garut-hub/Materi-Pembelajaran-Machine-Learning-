# Quiz Tugas 1 — Artificial Intelligence

Versi ini memakai Google Apps Script + Google Spreadsheet.

CATATAN PENTING:
Jumlah kategori yang diminta adalah 10 PG + 5 menjodohkan + 5 multi-jawaban + 5 esai = 25 butir soal, bukan 20. Kode ini memakai 25 soal agar semua kategori terpenuhi.

## Cara pasang
1. Buat Google Spreadsheet baru.
2. Extensions > Apps Script.
3. Buat file `Code.gs`, tempel isi Code.gs.
4. Buat file HTML bernama `Index`, tempel isi Index.html.
5. Jika script dibuat dari spreadsheet tersebut, biarkan SPREADSHEET_ID kosong.
6. Simpan.
7. Deploy > New deployment > Web app.
8. Execute as: Me.
9. Who has access: Anyone with the link (sesuaikan kebijakan akun sekolah).
10. Buka URL Web App.

Spreadsheet otomatis membuat sheet `Hasil Quiz`.

Kolom: Timestamp, Nama, Kelas, skor PG, skor menjodohkan, skor multi, skor esai, Nilai, Status, Ranking, Durasi.

## Bobot
PG 25%, Menjodohkan 20%, Multi-jawaban 25%, Esai 30%.

Esai memakai keyword sebagai penilaian otomatis awal. Guru dapat mengecek dan mengoreksi nilai esai langsung di Spreadsheet bila diperlukan.
